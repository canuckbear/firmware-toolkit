/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * (C) Copyright 2004-2010
 * Texas Instruments, <www.ti.com>
 */
#ifndef _OMAP4_I2C_H_
#define _OMAP4_I2C_H_

#define I2C_DEFAULT_BASE	I2C_BASE1

#endif /* _OMAP4_I2C_H_ */
